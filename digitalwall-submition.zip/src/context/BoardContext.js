import { createContext } from "react";
const BoardContext = createContext();
export default BoardContext;